package dao;

public class Operation {
    private Long codeOperation;
    private String designation;
    private Double montant;



    // Constructor
    public Operation(Long codeOperation, String designation, Double montant) {
        this.codeOperation = codeOperation;
        this.designation = designation;
        this.montant = montant;
    }
    // Getters and Setters
    public Long getCodeOperation() {
        return codeOperation;
    }

    public void setCodeOperation(Long codeOperation) {
        this.codeOperation = codeOperation;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public Double getMontant() {
        return montant;
    }

    public void setMontant(Double montant) {
        this.montant = montant;
    }
}
