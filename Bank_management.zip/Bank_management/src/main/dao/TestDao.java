package dao;

import java.util.Date;
import java.util.List;

public class TestDao {
    public static void main(String[] args) {
        // Create DAO instance
        IDao dao = new DaoImpl();

        try {
            // Test adding a client
            Client client = new Client();
           // Client client2 = new Client();

            client.setNom("Dupont");
            client.setPrenom("Jean");
            client.setTelephone("0123456789");


            // Test adding a client
           // client2.setNom("Hajer");
            // client2.setPrenom("Jean");
            // client2.setTelephone("0123456789");

            dao.ajouterClient(client);
            System.out.println("Client added successfully");
            client.setNom("ddd");
            client.setPrenom("Jeaddn");
            client.setTelephone("0123456789");
            System.out.println("pass");

            dao.ajouterClient(client);
            System.out.println("Client added successfully");


            // Test adding a compte
            Compte compte = new Compte();
            compte.setDateCreation(new Date());
            compte.setNumeroCompte("ACC1");
            compte.setOperations(1000.0);
            dao.ajouterCompte(compte);
            System.out.println("Compte added successfully");

            Compte compte2 = new Compte();
            compte2.setDateCreation(new Date());
            compte2.setNumeroCompte("ACC2");
            compte2.setOperations(1000.0);
            dao.ajouterCompte(compte2);
            System.out.println("Compte added successfully");

            // Test adding an operation
            Operation operation = new Operation();
            operation.setDesignation("Deposit");
            operation.setMontant(500.0);
            dao.ajouterOperation(operation);
            System.out.println("Operation added successfully");

            // Test consulting all clients
            List<Client> clients = dao.consulterTousClients();
            System.out.println("All clients:");
            for (Client c : clients) {
                System.out.println("Client: " + c.getNom() + " " + c.getPrenom());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}