package dao;

import java.util.List;

public interface IDao {
    public void ajouterClient(Client c);
    public void ajouterCompte(Compte cp);
    public void ajouterOperation(Operation op);
    public Client consulterClient(Long codeClient);
    public List<Client> consulterTousClients();
    public void supprimerClient(Long codeClient);
}