package dao;

import java.util.Date;
import java.util.List;

public class TestDao {
    public static void main(String[] args) {
        // Create DAO instance
        IDao dao = new DaoImpl();

        try {
            // Test adding a client
            Client client = new Client();
            client.setNom("Dupont");
            client.setPrenom("Jean");
            client.setTelephone("0123456789");
            dao.ajouterClient(client);
            System.out.println("Client added successfully");


            Client client2 = new Client();
            client2.setNom("dhdhdh");
            client2.setPrenom("Jean");
            client2.setTelephone("0123456789");
            dao.ajouterClient(client2);
            System.out.println("Client added successfully");

            // Test adding a compte
            Compte compte = new Compte("ACC001", new Date(), 1000.0);
            dao.ajouterCompte(compte);
            System.out.println("Compte added successfully");

            // Test adding an operation
            Operation operation = new Operation();
            operation.setDesignation("Deposit");
            operation.setMontant(500.0);
            dao.ajouterOperation(operation);
            System.out.println("Operation added successfully");

            // Test adding an operation
            Operation operation2 = new Operation();
            operation2.setDesignation("Deposit");
            operation2.setMontant(500.0);
            dao.ajouterOperation(operation2);
            System.out.println("Operation added successfully");


            // Test consulting all clients
            List<Client> clients = dao.consulterTousClients();
            System.out.println("All clients:");
            for (Client c : clients) {
                System.out.println("Client: " + c.getNom() + " " + c.getPrenom());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}