package dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.List;

public class DaoImpl implements IDao {
    @Override
    public void ajouterClient(Client c) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.save(c);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    @Override
    public void ajouterCompte(Compte cp) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.save(cp);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    @Override
    public void ajouterOperation(Operation op) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.save(op);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    @Override
    public Client consulterClient(Long codeClient) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Client client = null;
        try {
            client = (Client) session.get(Client.class, codeClient);
        } finally {
            session.close();
        }
        return client;
    }

    @Override
    public List<Client> consulterTousClients() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Client> clients = null;
        try {
            clients = session.createQuery("from Client").list();
        } finally {
            session.close();
        }
        return clients;
    }

    @Override
    public void supprimerClient(Long codeClient) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Client client = (Client) session.get(Client.class, codeClient);
            if (client != null) {
                session.delete(client);
            }
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
}