package org.example.springboot_recommendation.controller;

import org.example.springboot_recommendation.service.RecommendationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/recommendations")
public class RecommendationController {

    @Autowired
    private RecommendationService recommendationService;

    @GetMapping("/{productId}")
    public ResponseEntity<List<?>> getRecommendations(
            @PathVariable String productId,
            @RequestParam(defaultValue = "3") int nRecommendations) {

        List<?> recommendations = recommendationService.getRecommendationsForProduct(productId, nRecommendations);
        return ResponseEntity.ok(recommendations);
    }
}
