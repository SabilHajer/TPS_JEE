package org.example.springboot_recommendation.controller;

import org.example.springboot_recommendation.dto.UserInteractionDTO;
import org.example.springboot_recommendation.entity.UserInteraction;
import org.example.springboot_recommendation.service.InteractionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/interactions")
public class InteractionController {

    @Autowired
    private InteractionService interactionService;

    @PostMapping
    public ResponseEntity<UserInteractionDTO> logInteraction(@RequestBody InteractionRequest request) {
        UserInteraction interaction = interactionService.logInteraction(
                request.getUserId(),
                request.getProductId(),
                request.getInteractionType()
        );

        // Convert to DTO
        UserInteractionDTO dto = new UserInteractionDTO();
        dto.setId(interaction.getId());
        dto.setProductId(interaction.getProductId());
        dto.setInteractionType(interaction.getInteractionType());
        dto.setTimestamp(interaction.getTimestamp());

        return new ResponseEntity<>(dto, HttpStatus.CREATED);
    }

    // DTO class to encapsulate request
    static class InteractionRequest {
        private Long userId;
        private Long productId;
        private String interactionType;

        // Getters and setters
        public Long getUserId() {
            return userId;
        }

        public void setUserId(Long userId) {
            this.userId = userId;
        }

        public Long getProductId() {
            return productId;
        }

        public void setProductId(Long productId) {
            this.productId = productId;
        }

        public String getInteractionType() {
            return interactionType;
        }

        public void setInteractionType(String interactionType) {
            this.interactionType = interactionType;
        }
    }
}
