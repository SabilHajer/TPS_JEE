package org.example.springboot_recommendation.service;

import org.example.springboot_recommendation.entity.User;
import org.example.springboot_recommendation.entity.UserInteraction;
import org.example.springboot_recommendation.repository.UserInteractionRepository;
import org.example.springboot_recommendation.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class InteractionService {

    @Autowired
    private UserInteractionRepository interactionRepository;

    @Autowired
    private UserRepository userRepository;

    public UserInteraction logInteraction(Long userId, Long productId, String interactionType) {
        // Validate user existence
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User with ID " + userId + " not found"));

        // Create new interaction
        UserInteraction interaction = new UserInteraction();
        interaction.setUser(user);
        interaction.setProductId(productId);
        interaction.setInteractionType(interactionType);
        interaction.setTimestamp(LocalDateTime.now());

        // Save to database
        return interactionRepository.save(interaction);
    }
}
