package org.example.springboot_recommendation.client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class PythonRecommendationClient {

    @Value("${recommendation.api.url}")
    private String pythonApiUrl;

    private final RestTemplate restTemplate;

    public PythonRecommendationClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public List<?> getRecommendations(String productId, int nRecommendations) {
        // Prepare the request payload
        Map<String, Object> request = new HashMap<>();
        request.put("product_id", productId);
        request.put("n_recommendations", nRecommendations);

        // Make a POST request to the Python API
        return restTemplate.postForObject(
                pythonApiUrl + "/recommendations",
                request,
                List.class
        );
    }
}
