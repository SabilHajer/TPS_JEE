package org.example.springboot_recommendation.controller;

import org.example.springboot_recommendation.entity.User;
import org.example.springboot_recommendation.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpSession;

@Controller
public class AuthController {

    @Autowired
    private UserService userService;

    @GetMapping("/")
    public String home() {
        return "home"; // Renders home.html
    }

    @GetMapping("/login")
    public String loginPage() {
        return "login"; // Renders login.html
    }

    @PostMapping("/login")
    public String login(@RequestParam String email, 
                       @RequestParam String password,
                       HttpSession session,
                       RedirectAttributes redirectAttributes) {
        try {
            User user = userService.findByEmail(email);
            if (user != null && user.getPassword().equals(password)) { // Note: In production, use proper password hashing
                // Store user in session
                session.setAttribute("user", user);
                return "redirect:/catalog";
            } else {
                redirectAttributes.addFlashAttribute("error", "Invalid email or password");
                return "redirect:/login";
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error during login: " + e.getMessage());
            return "redirect:/login";
        }
    }

    @GetMapping("/signup")
    public String signupPage() {
        return "signup"; // Renders signup.html
    }

    @PostMapping("/signup")
    public String signup(@RequestParam String name,
                        @RequestParam String email,
                        @RequestParam String password,
                        @RequestParam String confirmPassword,
                        RedirectAttributes redirectAttributes) {
        
        // Validate passwords match
        if (!password.equals(confirmPassword)) {
            redirectAttributes.addFlashAttribute("error", "Passwords do not match");
            return "redirect:/signup";
        }

        // Create new user
        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setPassword(password); // Note: In production, use proper password hashing
        user.setProfileImage("/images/default-profile.png"); // Set default profile image
        
        try {
            userService.createUser(user);
            redirectAttributes.addFlashAttribute("success", "Account created successfully! Please login.");
            return "redirect:/login";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error creating account: " + e.getMessage());
            return "redirect:/signup";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }
}
