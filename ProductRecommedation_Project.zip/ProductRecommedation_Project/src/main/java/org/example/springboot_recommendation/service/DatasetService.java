package org.example.springboot_recommendation.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import org.example.springboot_recommendation.entity.Product;
import org.example.springboot_recommendation.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

@Service
public class DatasetService {

    @Autowired
    private ProductRepository productRepository;

    public void loadDatasetFromJson(String filePath) {
        ObjectMapper mapper = new ObjectMapper();
        ObjectReader reader = mapper.readerFor(Product.class);
        List<Product> products = new ArrayList<>();
        try {
            // Read line-delimited JSON and parse each line as a Product
            Files.lines(Paths.get(filePath)).forEach(line -> {
                try {
                    Product product = reader.readValue(line);
                    products.add(product);
                } catch (IOException e) {
                    throw new RuntimeException("Failed to parse line: " + line, e);
                }
            });
            productRepository.saveAll(products); // Save products to the database
            System.out.println("Dataset loaded successfully!");
        } catch (IOException e) {
            throw new RuntimeException("Failed to load dataset", e);
        }
    }
}
