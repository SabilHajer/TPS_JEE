package org.example.springboot_recommendation.controller;

import org.example.springboot_recommendation.service.DatasetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DatasetController {

    @Autowired
    private DatasetService datasetService;

    @PostMapping("/load-dataset")
    public String loadDataset() {
        String filePath = "C:/Users/hp/IdeaProjects/recommendation-system/data/preprocessed_products.json";
        datasetService.loadDatasetFromJson(filePath);
        return "Dataset loaded into the database successfully!";
    }
}
