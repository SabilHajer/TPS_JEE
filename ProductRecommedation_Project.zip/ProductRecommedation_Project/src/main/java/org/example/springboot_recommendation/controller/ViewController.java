package org.example.springboot_recommendation.controller;

import org.example.springboot_recommendation.entity.Product;
import org.example.springboot_recommendation.entity.User;
import org.example.springboot_recommendation.service.ProductService;
import org.example.springboot_recommendation.service.RecommendationService;
import org.example.springboot_recommendation.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpSession;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class ViewController {

    @Autowired
    private UserService userService;

    @Autowired
    private ProductService productService;

    @Autowired
    private RecommendationService recommendationService;

    @GetMapping("/catalog")
    public String catalog(HttpSession session,
                          Model model,
                          RedirectAttributes redirectAttributes,
                          @RequestParam(required = false) String search,
                          @RequestParam(required = false) String category,
                          @RequestParam(required = false) Double minPrice,
                          @RequestParam(required = false) Double maxPrice,
                          @RequestParam(required = false, defaultValue = "popular") String sort) {
        // Check if user is logged in
        User user = (User) session.getAttribute("user");
        if (user == null) {
            redirectAttributes.addFlashAttribute("error", "Please login to access the catalog");
            return "redirect:/login";
        }

        // Get all products
        List<Product> products = productService.fetchAllProducts();

        // Apply filters if any
        if (search != null && !search.isEmpty()) {
            products = products.stream()
                    .filter(p -> p.getTitle().toLowerCase().contains(search.toLowerCase()) ||
                            p.getDescription().toLowerCase().contains(search.toLowerCase()))
                    .toList();
        }

        if (category != null && !category.isEmpty()) {
            products = products.stream()
                    .filter(p -> p.getCategory().equals(category))
                    .toList();
        }

        if (minPrice != null) {
            products = products.stream()
                    .filter(p -> p.getPrice() >= minPrice)
                    .toList();
        }

        if (maxPrice != null) {
            products = products.stream()
                    .filter(p -> p.getPrice() <= maxPrice)
                    .toList();
        }

        // Apply sorting
        switch (sort) {
            case "price-low":
                products = products.stream()
                        .sorted((p1, p2) -> p1.getPrice().compareTo(p2.getPrice()))
                        .toList();
                break;
            case "price-high":
                products = products.stream()
                        .sorted((p1, p2) -> p2.getPrice().compareTo(p1.getPrice()))
                        .toList();
                break;
            case "newest":
                // Assuming you have a date field, otherwise remove this case
                break;
            default: // "popular" or any other value
                // You could sort by rating or number of reviews here
                break;
        }

        // Get unique categories for filter dropdown
        List<String> categories = productService.getAllCategories();

        // Add data to model
        model.addAttribute("products", products);
        model.addAttribute("categories", categories);
        model.addAttribute("currentCategory", category);
        model.addAttribute("currentSort", sort);
        model.addAttribute("search", search);
        model.addAttribute("minPrice", minPrice);
        model.addAttribute("maxPrice", maxPrice);
        model.addAttribute("user", user);

        return "catalog";
    }

    @GetMapping("/product/{id}")
    public String productDetails(@PathVariable Long id, Model model) {
        model.addAttribute("productId", id);
        return "product-details";
    }

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        // Get user from session
        User user = (User) session.getAttribute("user");
        if (user == null) {
            redirectAttributes.addFlashAttribute("error", "Please login to access the dashboard");
            return "redirect:/login";
        }

        // Add user to model
        model.addAttribute("user", user);

        // Add statistics
        Map<String, Integer> stats = new HashMap<>();
        stats.put("viewedCount", 0);
        stats.put("reviewCount", 0);
        stats.put("purchaseCount", 0);
        model.addAttribute("stats", stats);



        /*
        // Add recommendations from the RecommendationService
        List<Product> recommendations = recommendationService.getRecommendationsForUser(user.getId());
        model.addAttribute("recommendations", recommendations);

        model.addAttribute("recentActivities", Collections.emptyList());
        model.addAttribute("userReviews", Collections.emptyList());

      */


        return "dashboard";
    }
}
