package org.example.springboot_recommendation.dto;

import org.example.springboot_recommendation.entity.UserInteraction;

import java.util.List;

public class RecommendationRequest {

    private Long userId;
    private List<UserInteraction> interactions;

    // Constructor
    public RecommendationRequest(Long userId, List<UserInteraction> interactions) {
        this.userId = userId;
        this.interactions = interactions;
    }

    // Getters and Setters
    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public List<UserInteraction> getInteractions() {
        return interactions;
    }

    public void setInteractions(List<UserInteraction> interactions) {
        this.interactions = interactions;
    }
}
