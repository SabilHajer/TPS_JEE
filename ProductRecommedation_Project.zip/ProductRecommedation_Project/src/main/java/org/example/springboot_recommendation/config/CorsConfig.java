package org.example.springboot_recommendation.config;

public class CorsConfig {
}
