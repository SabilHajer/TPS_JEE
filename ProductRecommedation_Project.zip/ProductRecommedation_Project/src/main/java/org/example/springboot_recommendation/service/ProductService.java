package org.example.springboot_recommendation.service;

import org.example.springboot_recommendation.entity.Product;
import org.example.springboot_recommendation.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    // Fetch all products from the database
    public List<Product> fetchAllProducts() {
        return productRepository.findAll();
    }

    // Fetch a single product by ID from the database
    public Product fetchProductById(String id) {
        Optional<Product> product = productRepository.findById(id);
        return product.orElse(null); // Return null if not found (you can throw an exception here if preferred)
    }

    // Get all unique categories
    public List<String> getAllCategories() {
        return productRepository.findAll().stream()
                .map(Product::getCategory)
                .distinct()
                .collect(Collectors.toList());
    }
}
