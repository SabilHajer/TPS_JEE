package org.example.springboot_recommendation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRecommendationApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootRecommendationApplication.class, args);
    }

}
