package org.example.springboot_recommendation.controller;

import org.example.springboot_recommendation.entity.Product;
import org.example.springboot_recommendation.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    // Endpoint to fetch all products from the database
    @GetMapping
    public List<Product> getAllProducts() {
        return productService.fetchAllProducts();
    }

    // Endpoint to fetch a single product by ID from the database
    @GetMapping("/{id}")
    public Product getProductById(@PathVariable String id) {
        return productService.fetchProductById(id);
    }
}
