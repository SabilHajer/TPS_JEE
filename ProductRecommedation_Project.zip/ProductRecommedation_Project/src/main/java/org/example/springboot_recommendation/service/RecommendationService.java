package org.example.springboot_recommendation.service;

import org.example.springboot_recommendation.client.PythonRecommendationClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RecommendationService {

    @Autowired
    private PythonRecommendationClient pythonRecommendationClient;

    public List<?> getRecommendationsForProduct(String productId, int nRecommendations) {
        return pythonRecommendationClient.getRecommendations(productId, nRecommendations);
    }
}
