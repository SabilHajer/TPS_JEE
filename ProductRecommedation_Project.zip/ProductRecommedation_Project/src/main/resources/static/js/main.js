// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize all tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Product quantity controls
    const quantityControls = document.querySelectorAll('.quantity-control');
    quantityControls.forEach(control => {
        const input = control.querySelector('input');
        const decreaseBtn = control.querySelector('.decrease');
        const increaseBtn = control.querySelector('.increase');

        if (decreaseBtn && increaseBtn && input) {
            decreaseBtn.addEventListener('click', () => {
                const currentValue = parseInt(input.value);
                if (currentValue > 1) {
                    input.value = currentValue - 1;
                }
            });

            increaseBtn.addEventListener('click', () => {
                const currentValue = parseInt(input.value);
                input.value = currentValue + 1;
            });
        }
    });

    // Rating system
    const ratingStars = document.querySelectorAll('.rating-star');
    ratingStars.forEach(star => {
        star.addEventListener('click', function() {
            const rating = this.previousElementSibling.value;
            const stars = this.parentElement.querySelectorAll('.rating-star');
            
            // Reset all stars
            stars.forEach(s => s.classList.remove('active'));
            
            // Highlight selected stars
            let current = this;
            while (current) {
                current.classList.add('active');
                current = current.nextElementSibling;
            }
        });
    });

    // Search functionality
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        let timeout = null;
        searchInput.addEventListener('input', function() {
            clearTimeout(timeout);
            timeout = setTimeout(() => {
                // Implement search functionality here
                console.log('Searching for:', this.value);
            }, 500);
        });
    }

    // Filter functionality
    const filterForm = document.querySelector('.filter-form');
    if (filterForm) {
        filterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            const filters = Object.fromEntries(formData.entries());
            // Implement filter functionality here
            console.log('Applying filters:', filters);
        });
    }

    // Add to cart functionality
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.dataset.productId;
            const quantity = document.querySelector(`input[name="quantity"][data-product-id="${productId}"]`)?.value || 1;
            
            // Animation feedback
            this.classList.add('btn-success');
            this.textContent = 'Added to Cart!';
            
            setTimeout(() => {
                this.classList.remove('btn-success');
                this.textContent = 'Add to Cart';
            }, 2000);

            // Implement add to cart functionality here
            console.log('Adding to cart:', { productId, quantity });
        });
    });

    // Form validation
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!form.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });

    // Infinite scroll for product listing
    let isLoading = false;
    const productGrid = document.querySelector('.product-grid');
    if (productGrid) {
        window.addEventListener('scroll', function() {
            if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 1000 && !isLoading) {
                isLoading = true;
                // Implement loading more products here
                console.log('Loading more products...');
                setTimeout(() => {
                    isLoading = false;
                }, 1000);
            }
        });
    }

    // Image gallery
    const productImages = document.querySelectorAll('.product-image-thumbnail');
    const mainProductImage = document.querySelector('.product-image-main');
    if (productImages.length && mainProductImage) {
        productImages.forEach(image => {
            image.addEventListener('click', function() {
                mainProductImage.src = this.src;
                productImages.forEach(img => img.classList.remove('active'));
                this.classList.add('active');
            });
        });
    }
}); 