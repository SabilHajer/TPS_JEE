package org.example.springboot_recommendation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRecommendationApplicationTests {

    @Test
    void contextLoads() {
    }

}
