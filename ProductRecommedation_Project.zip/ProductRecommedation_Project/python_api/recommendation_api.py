from flask import Flask, request, jsonify
from recommandation import ProductRecommender
import os

app = Flask(__name__)

# Path to your product dataset
json_path = r"C:\Users\hp\IdeaProjects\Recommendation_Project\data\fixed_preprocessed_products.json" # Ensure this file exists in the python_api folder
if not os.path.exists(json_path):
    raise FileNotFoundError(f"JSON file not found: {json_path}")

# Initialize the recommendation system
recommender = ProductRecommender(json_path)

@app.route('/recommendations', methods=['POST'])
def get_recommendations():
    """
    API Endpoint: Get product recommendations.
    Expects JSON payload:
    - product_id: ID of the product to base recommendations on.
    - n_recommendations: Number of recommendations (default 3).
    """
    try:
        data = request.json
        product_id = data.get("product_id")
        n_recommendations = data.get("n_recommendations", 3)

        if not product_id:
            return jsonify({"error": "Missing 'product_id'"}), 400

        # Get recommendations
        recommendations = recommender.get_recommendations(product_id, n_recommendations)

        return jsonify(recommendations.to_dict(orient="records"))
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
