import json

# Path to your invalid JSON file
input_file = r"C:\Users\hp\IdeaProjects\Recommendation_Project\data\preprocessed_products.json"
# Path to save the corrected JSON file
output_file = r"C:\Users\hp\IdeaProjects\Recommendation_Project\data\fixed_preprocessed_products.json"

def fix_json_file(input_file, output_file):
    try:
        # Read the file with multiple JSON objects
        with open(input_file, 'r') as file:
            lines = file.readlines()

        # Convert each line (JSON object) into a Python dictionary
        products = [json.loads(line) for line in lines]

        # Remove duplicate products based on the 'id' field
        unique_products = {product['id']: product for product in products}.values()

        # Save the corrected JSON array to a new file
        with open(output_file, 'w') as file:
            json.dump(list(unique_products), file, indent=4)

        print(f"Fixed JSON file saved to: {output_file}")
    except Exception as e:
        print(f"Error fixing JSON file: {str(e)}")

# Run the function
fix_json_file(input_file, output_file)
