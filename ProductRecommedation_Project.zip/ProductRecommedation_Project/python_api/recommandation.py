import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from scipy.sparse import csr_matrix
import json
import logging
import faiss

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ProductRecommender:
    def __init__(self, json_path: str):
        """
        Initialize the recommender system with data from a JSON file.

        Args:
            json_path (str): Path to the JSON file containing product data.
        """
        self.df = self._load_json_data(json_path)
        self.feature_matrix = None
        self.faiss_index = None

    def _load_json_data(self, json_path: str) -> pd.DataFrame:
        """
        Load and validate product data from JSON file.

        Args:
            json_path (str): Path to JSON file.

        Returns:
            pd.DataFrame: DataFrame containing product data.
        """
        try:
            with open(json_path, 'r') as file:
                data = json.load(file)

            # Convert to DataFrame
            df = pd.DataFrame(data)

            # Validate required columns
            required_columns = ['id', 'category', 'country', 'description', 'price', 'title']
            missing_columns = [col for col in required_columns if col not in df.columns]

            if missing_columns:
                raise ValueError(f"Missing required columns: {missing_columns}")

            # Convert price to numeric, handling any non-numeric values
            df['price'] = pd.to_numeric(df['price'], errors='coerce')

            # Drop rows with missing values
            df = df.dropna()

            logger.info(f"Successfully loaded {len(df)} products from JSON file.")
            return df

        except FileNotFoundError:
            logger.error(f"JSON file not found: {json_path}")
            raise
        except json.JSONDecodeError:
            logger.error(f"Invalid JSON file: {json_path}")
            raise
        except Exception as e:
            logger.error(f"Error loading data: {str(e)}")
            raise

    def create_feature_matrix(self) -> None:
        """
        Create feature matrix from product data.
        """
        try:
            # One-hot encode categorical variables
            category_encoded = pd.get_dummies(self.df['category'], prefix='category')
            country_encoded = pd.get_dummies(self.df['country'], prefix='country')
            description_encoded = pd.get_dummies(self.df['description'], prefix='desc')

            # Normalize prices
            price_normalized = (self.df['price'] - self.df['price'].min()) / (
                    self.df['price'].max() - self.df['price'].min()
            )

            # Combine features
            self.feature_matrix = pd.concat([
                category_encoded,
                country_encoded,
                description_encoded,
                price_normalized.rename('price_norm')
            ], axis=1)

            # Ensure all columns are numeric
            self.feature_matrix = self.feature_matrix.astype(float)

            logger.info("Feature matrix created successfully.")

        except Exception as e:
            logger.error(f"Error creating feature matrix: {str(e)}")
            raise

    def calculate_similarity(self):
        """
        Use Faiss to find approximate nearest neighbors for recommendations.
        """
        try:
            if self.feature_matrix is None:
                self.create_feature_matrix()

            # Convert the feature matrix to NumPy array
            features = self.feature_matrix.to_numpy().astype('float32')

            # Build the Faiss index
            index = faiss.IndexFlatL2(features.shape[1])
            index.add(features)

            # Save the Faiss index for later use
            self.faiss_index = index
            logger.info("Faiss index built successfully")

        except Exception as e:
            logger.error(f"Error building Faiss index: {str(e)}")
            raise

    def get_recommendations(self, product_id: str, n_recommendations: int = 3) -> pd.DataFrame:
        """
        Get product recommendations based on product ID.

        Args:
            product_id (str): ID of the product to get recommendations for.
            n_recommendations (int): Number of recommendations to return.

        Returns:
            pd.DataFrame: DataFrame containing recommended products.
        """
        try:
            if not hasattr(self, 'faiss_index') or self.faiss_index is None:
                self.calculate_similarity()

            # Find the index of the product
            if product_id not in self.df['id'].values:
                raise ValueError(f"Product ID {product_id} not found in dataset")

            product_idx = self.df[self.df['id'] == product_id].index[0]

            # Query the Faiss index for nearest neighbors
            _, similar_indices = self.faiss_index.search(
                self.feature_matrix.to_numpy()[product_idx:product_idx + 1].astype('float32'),
                n_recommendations + 1
            )

            # Get the recommended products
            recommendations = self.df.iloc[similar_indices[0][1:]][['id', 'title', 'price', 'category']]

            # Remove duplicates by 'id'
            recommendations = recommendations.drop_duplicates(subset='id')

            return recommendations

        except Exception as e:
            logger.error(f"Error getting recommendations: {str(e)}")
            raise
