package com.example.demo.controller;

import com.example.demo.model.Stage;
import com.example.demo.model.Student;
import com.example.demo.service.StageService;
import com.example.demo.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/stages")
public class StageController {

    @Autowired
    private StageService stageService;

    @Autowired
    private StudentService studentService;

    // Display the list of stages
    @GetMapping
    public String getAllStages(Model model) {
        List<Stage> stages = stageService.getAllStages();
        model.addAttribute("stages", stages);
        return "stages_list";  // Ensure the stages_list.html file exists in /templates
    }

    // Show the form to add a new stage
    @GetMapping("/add")
    public String showAddStageForm(Model model) {
        List<Student> students = studentService.getAllStudents();  // Load students for the dropdown
        model.addAttribute("students", students);
        model.addAttribute("stage", new Stage());
        return "add_stage";  // Ensure the add_stage.html file exists in /templates
    }

    // Handle adding a new stage
    @PostMapping("/add")
    public String addStage(@ModelAttribute("stage") Stage stage) {
        stageService.saveStage(stage);
        return "redirect:/stages";  // Redirect to the stage list after adding
    }

    // Handle deleting a stage
    @GetMapping("/delete/{id}")
    public String deleteStage(@PathVariable Long id) {
        stageService.deleteStage(id);
        return "redirect:/stages";  // Redirect to the stage list after deleting
    }
}
