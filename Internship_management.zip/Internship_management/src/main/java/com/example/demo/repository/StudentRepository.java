package com.example.demo.repository;

import com.example.demo.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {

    // Method to find students by name
    List<Student> findByName(String name);

    // Method to find students by email
    List<Student> findByEmail(String email);

    // Method to find students older than a certain age
    List<Student> findByAgeGreaterThan(int age);
}
