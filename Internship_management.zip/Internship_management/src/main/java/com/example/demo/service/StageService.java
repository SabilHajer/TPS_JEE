package com.example.demo.service;

import com.example.demo.model.Stage;
import com.example.demo.repository.StageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StageService {

    @Autowired
    private StageRepository stageRepository;

    // Retrieve all stages
    public List<Stage> getAllStages() {
        return stageRepository.findAll();
    }

    // Save a new stage or update an existing one
    public void saveStage(Stage stage) {
        stageRepository.save(stage);
    }

    // Retrieve a stage by ID
    public Optional<Stage> getStageById(Long id) {
        return stageRepository.findById(id);
    }

    // Delete a stage by ID
    public void deleteStage(Long id) {
        stageRepository.deleteById(id);
    }
}
